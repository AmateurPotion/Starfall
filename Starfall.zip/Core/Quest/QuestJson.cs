namespace Starfall.Core.Quest
{
	public class QuestJson
	{
		public string Title { get; set; }
		public string Comment { get; set; }
		public string Goal { get; set; }
		public string Reward { get; set; }
		public string State { get; set; }
	}
}
