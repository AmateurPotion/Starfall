using System.Text.Json;
using Spectre.Console;
using Starfall.Contents.Binary;
using Starfall.Contents.Json;
using Starfall.Core;
using Starfall.Core.Quest;
using Starfall.IO;
using Starfall.IO.CUI;
using Starfall.Contents;


namespace Starfall
{
	public static class GameManager
	{
		public static bool Loaded { get; private set; } = false;
		public static readonly Dictionary<string, Item> items = [];
		public static readonly Dictionary<string, MonsterData> monsters = [];
		public static readonly Dictionary<string, QuestData> quests = [];
		public static readonly Dictionary<string, Skill> skills = [];
		public static readonly Dictionary<string, Event> events = [];
		public static readonly Dictionary<string, FloorData> floors = [];
		public static Game? Instance { get; private set; }


		public static void Init()
		{
			if (Loaded) return;
			StorageController.Init();
			Console.Title = "StarFall";

			// Item Json 파일 불러오기
			foreach (var info in new DirectoryInfo("./Resources/items/").GetFiles())
			{
				try
				{
					if (info.Name.Contains(".json"))
					{
						var name = info.Name.Replace(".json", "");
						var stream = info.OpenRead();
						var data = JsonSerializer.Deserialize<Item>(stream);

						items[name] = data;

						stream.Close();
					}
				}
				catch (JsonException) { }

			}

			// foreach 문 넣었음   by. 박재현 
			foreach (var info in new DirectoryInfo("./Resources/monster/").GetFiles())
			{
				try
				{
					if (info.Name.Contains(".json"))
					{
						var name = info.Name.Replace(".json", "");
						var stream = info.OpenRead();
						var data = JsonSerializer.Deserialize<MonsterData>(stream);

						monsters[name] = data;

						stream.Close();
					}
				}
				catch (JsonException) { }
			}


			// 스킬 불러오기
			ContentLoader.Load();

			// 퀘스트 불러오기 by. 최영임
			foreach (var file in new DirectoryInfo("./Resources/quests/").GetFiles("*.json"))
			{
				var name = Path.GetFileNameWithoutExtension(file.Name);

				try
				{
					using var stream = file.OpenRead();

					// QuestJson을 먼저 역직렬화
					var raw = JsonSerializer.Deserialize<QuestJson>(stream);

					// QuestData로 변환
					if (raw is not null)
					{
						var data = QuestData.FromJson(raw);
						quests[name] = data;
					}
					else
					{
						Console.WriteLine($"역직렬화 실패: {file.Name}");
					}
				}
				catch (Exception ex)
				{
					Console.WriteLine($"json 파일 로드 실패 ({file.Name}): {ex.Message}");
				}
			}

			Loaded = true;
		}

		public static Game StartGame(GameData data)
		{
			Instance = new Game(data);
			Instance.Start();

			return Instance;
		}

		public static void JoinGame()
		{

		}

		// 추가 by. 최영임 
		// Program.cs에서 가져옴. 
		public static void EnterMain()
		{
		Menu:
			Console.Clear();
			ConsoleUtil.PrintTextFile("Starfall.Resources.intro.txt");
			Console.WriteLine();

			StorageController.SetSaveName("default");
			switch (MenuUtil.OpenMenu("새로운 여정", "데이터 불러오기", "다른 여정 참여"))
			{
				case 0:
					// 새로운 여정 - 새 게임
					// 추가 by. 최영임 
					// 수정 by. 최영임 
					// 플레이어 첫 생성
					CreatePlayer.CreateNewPlayer();
					break;

				case 1:
					// 데이터 불러오기 - 데이터 불러오기
					Console.Clear();
					var menu = (from path in StorageController.GetSaveNames() select path.Replace("./saves/world\\", "")).ToArray();

					AnsiConsole.MarkupLine("불러올 데이터를 선택하세요. \n");
					var select = MenuUtil.OpenMenu([.. menu, "\n돌아가기"]);

					if (select > -1 && select < menu.Length)
					{
						StorageController.SetSaveName(menu[select]);
						GameManager.StartGame(StorageController.LoadBinary<GameData>("data"));
					}
					else goto Menu;
					break;

				case 2:
					// 다른 여정 참여 - 다른 여정 참여
					GameManager.JoinGame();
					Console.WriteLine("개발중입니다.");
					Console.ReadKey();
					goto Menu;

				case -1: goto Menu;
			}
		}
	}
}
