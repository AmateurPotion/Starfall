﻿namespace Starfall;

public static class Program
{
    public static void Main(params string[] args)
    {
        GameManager.Init();

        GameManager.EnterMain();
    }
}